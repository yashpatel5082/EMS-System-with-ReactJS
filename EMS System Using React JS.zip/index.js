const express = require("express");
const mongoose = require('mongoose');
const { ApolloServer } = require('apollo-server-express');
const Employee = require('./employee-model.js')

const app = express();
const port = 3000;
const typeDefs = `
  type emp {
    fName: String
    lName: String
    dept: String
    empType: String
    age: Int
    doj: String
    title: String
    status: Boolean
  }
  type Query {
    getEmployeeDataFunc: [emp]
  }
  type Mutation {
    addEmployeeFunc(
        fName: String
        lName: String
        dept: String
        empType: String
        age: Int
        title: String
        status: Boolean
    ): emp
  }
`;
const getEmployeeDataFunc = async () => {
	return  await Employee.find({},function (err, data) {
    if (err){
      return err;
    } 
    return data;
  }).clone()
}
const addEmployeeFunc = async (e, data) => {
  const res = await Employee.create(data);
  return res
}
const resolvers = {
    Query: {
        getEmployeeDataFunc
    },
    Mutation: {
        addEmployeeFunc
    }
  }
const apollo = new ApolloServer({
    typeDefs,
    resolvers
})

mongoose.connect('mongodb+srv://admin:VmzLOtYgK3EjKn0x@cluster0.dfudem0.mongodb.net/test');
mongoose.connection.on("connected", function(){ console.log("Application is succesfully connected to the Databse");})

apollo.start().then(function(){
	apollo.applyMiddleware({app, path: '/graphql', cors: true})
});

app.use(express.static("public"));

app.listen(port,()=>{
    console.log("server running on the",port);
})

app.get("/",(req,res)=>{
    res.render("index.html");
})
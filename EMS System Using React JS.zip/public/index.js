const TableRows = ({
  data
}) => {
  return /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", null, data.fName), /*#__PURE__*/React.createElement("td", null, data.lName), /*#__PURE__*/React.createElement("td", null, data.age), /*#__PURE__*/React.createElement("td", null, new Date(data.doj).toLocaleDateString("en-US")), /*#__PURE__*/React.createElement("td", null, data.title), /*#__PURE__*/React.createElement("td", null, data.dept), /*#__PURE__*/React.createElement("td", null, data.empType), /*#__PURE__*/React.createElement("td", null, data.status ? 'Working' : 'Retired'));
};
const Table = ({
  employeesData
}) => {
  const rows = employeesData.map((data, i) => /*#__PURE__*/React.createElement(TableRows, {
    key: i,
    data: data
  }));
  return /*#__PURE__*/React.createElement("table", null, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "First Name"), /*#__PURE__*/React.createElement("th", null, "Last Name"), /*#__PURE__*/React.createElement("th", null, "Age"), /*#__PURE__*/React.createElement("th", null, "Date Of Join"), /*#__PURE__*/React.createElement("th", null, "Title"), /*#__PURE__*/React.createElement("th", null, "Dept"), /*#__PURE__*/React.createElement("th", null, "Emp Type"), /*#__PURE__*/React.createElement("th", null, "Curr Status"))), /*#__PURE__*/React.createElement("tbody", null, rows));
};
const Form = ({
  addEmployeeFunc
}) => {
  return /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      const data = {
        fName: e.target.fName.value,
        lName: e.target.lName.value,
        age: Number(e.target.age.value),
        title: e.target.title.value,
        dept: e.target.dept.value,
        empType: e.target.empType.value,
        status: true
      };
      addEmployeeFunc(data);
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "text",
    name: "fName",
    placeholder: "First Name",
    required: true
  }), /*#__PURE__*/React.createElement("input", {
    type: "text",
    name: "lName",
    placeholder: "Last Name",
    required: true
  }), /*#__PURE__*/React.createElement("input", {
    type: "number",
    name: "age",
    placeholder: "Age",
    min: "1",
    max: "100",
    required: true
  }), /*#__PURE__*/React.createElement("select", {
    name: "title",
    required: true
  }, /*#__PURE__*/React.createElement("option", {
    value: "Employee"
  }, "Employee"), /*#__PURE__*/React.createElement("option", {
    value: "Manager"
  }, "Manager"), /*#__PURE__*/React.createElement("option", {
    value: "Director"
  }, "Director"), /*#__PURE__*/React.createElement("option", {
    value: "VP"
  }, "VP")), /*#__PURE__*/React.createElement("select", {
    name: "dept",
    required: true
  }, /*#__PURE__*/React.createElement("option", {
    value: "IT"
  }, "IT"), /*#__PURE__*/React.createElement("option", {
    value: "Marketing"
  }, "Marketing"), /*#__PURE__*/React.createElement("option", {
    value: "HR"
  }, "HR"), /*#__PURE__*/React.createElement("option", {
    value: "Engineering"
  }, "Engineering")), /*#__PURE__*/React.createElement("select", {
    name: "empType",
    required: true
  }, /*#__PURE__*/React.createElement("option", {
    value: "FullTime"
  }, "Full Time"), /*#__PURE__*/React.createElement("option", {
    value: "PartTime"
  }, "Part Time"), /*#__PURE__*/React.createElement("option", {
    value: "Contract"
  }, "Contract"), /*#__PURE__*/React.createElement("option", {
    value: "Seasonal"
  }, "Seasonal")), /*#__PURE__*/React.createElement("button", {
    type: "submit"
  }, "Submit"));
};
const EmployeeDirectory = () => {
  let [employeesData, setEmployeesData] = React.useState([]);
  const getEmployeeDataFunc = () => {
    const query = `
			query {
				getEmployeeDataFunc{
					fName
					lName
					dept
					empType
					age
					doj
					title
					status
				}
			}
		`;
    fetch('/graphql', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        query
      })
    }).then(async res => {
      const r = await res.json();
      setEmployeesData(r.data.getEmployeeDataFunc);
    });
  };
  const addEmployeeFunc = data => {
    const query = `
			mutation {
				addEmployeeFunc(
					fName: "${data.fName}"
					lName: "${data.lName}"
					dept: "${data.dept}"
					empType: "${data.empType}"
					age: ${data.age}
					title: "${data.title}"
					status: ${data.status}
				) {
					fName
					lName
					dept
					empType
					age
					doj
					title
					status
				}   
			}
		`;
    fetch('/graphql', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        query
      })
    }).then(() => {
      getEmployeeDataFunc();
    });
  };
  React.useEffect(function () {
    getEmployeeDataFunc();
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    id: "empList"
  }, /*#__PURE__*/React.createElement("h2", null, "Employee Table"), /*#__PURE__*/React.createElement("hr", null), /*#__PURE__*/React.createElement(Table, {
    employeesData: employeesData
  }), /*#__PURE__*/React.createElement("h2", null, "Add Employee"), /*#__PURE__*/React.createElement("hr", null), /*#__PURE__*/React.createElement(Form, {
    addEmployeeFunc: addEmployeeFunc
  }));
};
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render( /*#__PURE__*/React.createElement(EmployeeDirectory, null));
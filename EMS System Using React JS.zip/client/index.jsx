const TableRows = ({data}) => {
	return (
		<tr>
			<td>{data.fName}</td>
			<td>{data.lName}</td>
			<td>{data.age}</td>
			<td>{(new Date(data.doj)).toLocaleDateString("en-US")}</td>
			<td>{data.title}</td>
			<td>{data.dept}</td>
			<td>{data.empType}</td>
			<td>{data.status ? 'Working' : 'Retired'}</td>
		</tr>
  )
}

const Table = ({employeesData}) => {
	const rows = employeesData.map( (data, i) => (
		<TableRows 
			key={i}
			data={data}
		/>
	));
	
	return (
		<table>
			<thead>
				<tr>
					<th>First Name</th>
					<th>Last Name</th>
					<th>Age</th>
					<th>Date Of Join</th>
					<th>Title</th>
					<th>Dept</th>
					<th>Emp Type</th>
					<th>Curr Status</th>
				</tr>
			</thead>
			<tbody>
				{ rows }
			</tbody>
		</table>
	)
}

const Form = ({addEmployeeFunc}) => {
	return (
		<form onSubmit={(e) => {
				e.preventDefault();
				const data = {
					fName: e.target.fName.value,
					lName: e.target.lName.value,
					age: Number(e.target.age.value),
					title: e.target.title.value,
					dept: e.target.dept.value,
					empType: e.target.empType.value,
					status: true
				};
				addEmployeeFunc(data);
			}}
		>
			<input type="text" name="fName" placeholder="First Name" required></input>
			<input type="text" name="lName" placeholder="Last Name" required></input>
			<input type="number" name="age" placeholder="Age" min="1" max="100" required></input>
			<select name="title" required>
				<option value="Employee">Employee</option>
				<option value="Manager">Manager</option>
				<option value="Director">Director</option>
				<option value="VP">VP</option>
			</select>
			<select name="dept" required>
				<option value="IT">IT</option>
				<option value="Marketing">Marketing</option>
				<option value="HR">HR</option>
				<option value="Engineering">Engineering</option>
			</select>
			<select name="empType" required>
				<option value="FullTime">Full Time</option>
				<option value="PartTime">Part Time</option>
				<option value="Contract">Contract</option>
				<option value="Seasonal">Seasonal</option>
			</select>
			<button type="submit">Submit</button>
		</form>
	)
}

const EmployeeDirectory = () => {
	let [employeesData, setEmployeesData] = React.useState([]);

	const getEmployeeDataFunc = () => {
		const query = `
			query {
				getEmployeeDataFunc{
					fName
					lName
					dept
					empType
					age
					doj
					title
					status
				}
			}
		`;
		fetch('/graphql', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json'},
			body: JSON.stringify({ query })
		}).then(async (res) => {
				const r = await res.json()
				setEmployeesData(r.data.getEmployeeDataFunc)
		})
	}

	const addEmployeeFunc = (data) => {
		const query = `
			mutation {
				addEmployeeFunc(
					fName: "${data.fName}"
					lName: "${data.lName}"
					dept: "${data.dept}"
					empType: "${data.empType}"
					age: ${data.age}
					title: "${data.title}"
					status: ${data.status}
				) {
					fName
					lName
					dept
					empType
					age
					doj
					title
					status
				}   
			}
		`;

		fetch('/graphql', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json'},
			body: JSON.stringify({ query })
		}).then(()=>{
			getEmployeeDataFunc()
		});
	}

	React.useEffect(function(){
		getEmployeeDataFunc();
	}, []);

	return (
		<div id="empList">
			<h2>Employee Table</h2>
			<hr/>
			<Table employeesData={employeesData} />
			<h2>Add Employee</h2>
			<hr/>
			<Form addEmployeeFunc={addEmployeeFunc}/>
		</div>
	)
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <EmployeeDirectory />
)
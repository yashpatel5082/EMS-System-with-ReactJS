const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const EmployeeSchema = new Schema({
    fName: String,
    lName: String,
    dept: String,
    empType: String,
    age: Number,
    doj: { type: Date, default: new Date() },
    title: String,
    status: Boolean
});
const Employee = mongoose.model('Employee', EmployeeSchema, "employees");
module.exports = Employee;